from zdaemon.zdctl import main
main()